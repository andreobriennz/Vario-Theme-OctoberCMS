# Components

### Generic AJAX Form

By default renders a generic contact form to show the basic of Magic Forms.

Feel free to copy the included HTML and modify to fit your needs.


### Empty AJAX Form

Create a empty template for your custom form; override HTML with your fields but remember to keep form tags and flash messages container.