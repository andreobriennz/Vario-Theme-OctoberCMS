# Custom Validation Messages

Refer to Laravel documentation, [Working With Error Messages](https://laravel.com/docs/5.1/validation#working-with-error-messages).

Example: ```email.required``` or ```name.alpha```